
const { readFileSync, writeFileSync } = require('fs');
const COMMAND_FILE = 'command.json';

export default function handler(req, res) {
  if (req.method === 'POST') {
    writeFileSync(COMMAND_FILE, JSON.stringify({ command: 'turn' }));
    return res.status(200).end('ok');
  }
  res.status(405).end();
}
